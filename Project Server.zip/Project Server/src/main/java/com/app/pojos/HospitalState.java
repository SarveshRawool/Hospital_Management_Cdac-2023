package com.app.pojos;

public enum HospitalState {
	ACTIVE,INACTIVE;
}
