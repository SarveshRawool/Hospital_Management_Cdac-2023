package com.app.pojos;

public enum StatusType {
	PENDING,CANCELLED,DONE;
}
